<?php
    session_start();
    $database_name = "footwear store";
    $con = mysqli_connect("localhost","root","",$database_name);
	?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search</title>
<link rel="stylesheet" href="style1.css">
        <link rel="stylesheet" href="form.css" >
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity=  "sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
        @import url('https://fonts.googleapis.com/css?family=Titillium+Web');
        *{
            font-family: 'Titillium Web', sans-serif;
		
        }
	
        .product{
            border: 1px solid #eaeaec;
            margin: 14px 5px 6px -3px;
            padding: 10px ;
            text-align: center;
            background-color: #efefef;
			margin-right:12px;
        }
        table, th, tr{
            text-align: center;
			width:22px;
        }
        .title2{
            text-align: center;
            color: #9400D3;
            background-color: #efefef;
            padding: 2%;
        }
        h2{
            text-align: center;
            color: #9400D3;
            background-color: #efefef;
            padding: 2%;
        }
		img-responsive
		{
			width:2%;
		}
        table th{
            background-color: #efefef;
        }
		.btn-success
		{
			background-color:#4B0082;
		}
		.form-control
		{
			margin-left:0px;
		}
		.btn-view{
		background-color:#20B2AA
		}
    </style>
</head>

<body>
<div class="top-nav-bar">
          <div class="search-box">
             <i class ="fa fa-bars" id="menu-btn" onclick="openmenu()"></i>
             <i class ="fa fa-times"id="close-btn" onclick="closemenu()"></i>
        <a href="index.php"><img src="purple-logo.png" class="logo"></a>
         <input type="text" class="form-control" name="search" placeholder="Search..">
          
         <button class="btn btn-default" type="Submit"> 
         
            <span class="input-group-text"><i class="fa fa-search"></i></span> </button>
             </div>
            
             
             <div class="menu-bar">
             <ul>
                 <li><a href="check.php"><i class="fa fa-list"></i> Order</a></li>
                 <li><a href="register.php">Sign Up</a></li>
                 <li><a href="login.php">Log In</a></li>
             </ul>
             </div>
         </div>
 
        <h2 >Results</h2>
 <?php 


if(isset($_POST['search'])) {
    $s = $_POST['search'];
    $s = preg_replace("#[^0-9a-z]#i","", $s);
    $query = mysqli_query($con,"SELECT * FROM product WHERE productName LIKE '%$s%' OR color LIKE '%$s%' ") or die ("could not search!");
    $count = mysqli_num_rows ($query);
    if($count ==0 ){
        echo "No Results";
    } 
    else {
        while($row = mysqli_fetch_array($query))
        { ?>

          <div class="col-md-3">

                        <form method="post">

                            <div class="product">
                                <img src="<?php echo $row["image"]; ?>" class="img-responsive">
                                <h5 class="text-info"><?php echo $row["productName"]; ?></h5>
                                <h5 class="text-danger">Rs. <?php echo $row["price"]; ?></h5>
                            
                                <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                                 
               
              </div>
           </div>
           </form>
        </div>
       
       <?php }  
    }
  }?>
  
  </body>
  </html